<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой Блокнот</title>
    <!-- Подключаем Tailwind напрямую из сети, чтобы не настраивать Vite -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Подключаем Livewire -->
    @livewireStyles
</head>
<body class="bg-gray-50 min-h-screen py-12">
    <div class="container mx-auto px-4">
        <h1 class="text-4xl font-extrabold text-center text-gray-900 mb-2">📝 Блокнот</h1>
        <p class="text-center text-gray-500 mb-10">Мгновенный поиск на Livewire и MeiliSearch</p>
        
        <livewire:search-notes />
    </div>

    @livewireScripts
</body>
</html>
