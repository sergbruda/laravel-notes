<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заметки и Погода</title>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <style>
        :root {
            --bg-body: #f4f7f6; --bg-card: #ffffff; --text-main: #333333; --text-muted: #7f8c8d;
            --border-main: #e9ecef; --border-input: #ccc; --bg-input: #ffffff;
            --editor-bg: #ffffff; --badge-home-bg: #3498db; --badge-work-bg: #e74c3c; 
            --badge-rest-bg: #2ecc71; --badge-none-bg: #95a5a6;
            --weather-gradient: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --weather-glass: rgba(255, 255, 255, 0.15); --weather-glass-border: rgba(255, 255, 255, 0.2);
            --weather-glass-hover: rgba(255, 255, 255, 0.25); --success-color: #2ecc71;
        }
        [data-theme="dark"] {
            --bg-body: #121212; --bg-card: #1e1e1e; --text-main: #e4e4e4; --text-muted: #a0a0a0;
            --border-main: #333333; --border-input: #444444; --bg-input: #2c2c2c;
            --editor-bg: #2c2c2c; 
            --badge-home-bg: #2980b9; --badge-work-bg: #c0392b; --badge-rest-bg: #27ae60; --badge-none-bg: #7f8c8d;
            --weather-gradient: linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%);
            --weather-glass: rgba(255, 255, 255, 0.05); --weather-glass-border: rgba(255, 255, 255, 0.1);
            --weather-glass-hover: rgba(255, 255, 255, 0.15); --success-color: #27ae60;
        }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-body); color: var(--text-main); margin: 0; padding: 20px; transition: background-color 0.3s ease, color 0.3s ease; }
        .container { max-width: 900px; margin: 0 auto; }
        .card { background: var(--bg-card); border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); border: 1px solid var(--border-main); transition: background-color 0.3s ease, border-color 0.3s ease; }
        h1, h2 { margin-top: 0; }
        .weather-card { background: var(--weather-gradient); border-radius: 15px; padding: 30px; color: white; box-shadow: 0 10px 25px rgba(0,0,0,0.4); margin-bottom: 20px; transition: background 0.3s ease; }
        .weather-main { display: flex; align-items: center; gap: 20px; margin-bottom: 30px; border-bottom: 1px solid rgba(255,255,255,0.2); padding-bottom: 20px; }
        .weather-main img { width: 85px; height: 85px; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.2)); }
        .weather-temp { font-size: 3.5em; font-weight: bold; text-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .weather-city { font-size: 1.1em; opacity: 0.8; letter-spacing: 1px; text-transform: uppercase; }
        .weather-desc { font-size: 1.2em; opacity: 0.9; }
        .forecast-container { display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; }
        .forecast-day { text-align: center; background: var(--weather-glass); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); padding: 15px 5px; border-radius: 12px; border: 1px solid var(--weather-glass-border); transition: transform 0.2s, background 0.2s; }
        .forecast-day:hover { transform: translateY(-5px); background: var(--weather-glass-hover); }
        .forecast-day img { width: 45px; height: 45px; filter: drop-shadow(0 2px 3px rgba(0,0,0,0.2)); }
        .forecast-temp { font-weight: bold; font-size: 1.3em; margin: 8px 0; }
        .forecast-date { font-size: 0.85em; font-weight: bold; opacity: 0.9; }
        .forecast-desc { font-size: 0.8em; opacity: 0.8; text-transform: capitalize; }
        .counter { font-size: 1.2em; color: var(--text-muted); text-align: right; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .logout-form { display: inline; }
        .theme-btn { background: none; border: none; font-size: 1.8em; cursor: pointer; transition: transform 0.3s; }
        .theme-btn:hover { transform: rotate(30deg); }
        form { display: flex; flex-direction: column; gap: 10px; }
        input[type="text"], textarea, select, input[type="date"] { padding: 10px; border: 1px solid var(--border-input); border-radius: 5px; font-size: 1em; width: 100%; box-sizing: border-box; background: var(--bg-input); color: var(--text-main); transition: background-color 0.3s ease, border-color 0.3s ease; }
        .btn { padding: 10px 15px; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 1em; text-decoration: none; display: inline-block; text-align: center; }
        .btn-success { background: var(--success-color); } .btn-success:hover { background: #219a52; }
        .btn-warning { background: #f39c12; } .btn-warning:hover { background: #e67e22; }
        .btn-danger { background: #e74c3c; } .btn-danger:hover { background: #c0392b; }
        .btn-secondary { background: #95a5a6; } .btn-secondary:hover { background: #7f8c8d; }
        .btn-info { background: #3498db; } .btn-info:hover { background: #2980b9; }
        .note-item { border-bottom: 1px solid var(--border-main); padding: 15px 0; transition: border-color 0.3s; }
        .note-item:last-child { border-bottom: none; }
        .badge { padding: 4px 10px; border-radius: 15px; font-size: 0.8em; color: white; display: inline-block; margin-bottom: 8px; }
        .badge-home { background: var(--badge-home-bg); } .badge-work { background: var(--badge-work-bg); } 
        .badge-rest { background: var(--badge-rest-bg); } .badge-none { background: var(--badge-none-bg); }
        .note-actions { margin-top: 10px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .edit-form { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; width: 100%; margin-top: 10px; padding-top: 10px; border-top: 1px dashed var(--border-main); }
        .edit-form input, .edit-form select { width: auto; flex-grow: 1; }
        .success { color: var(--success-color); font-weight: bold; margin-bottom: 15px; }
        .current-time { font-size: 0.9em; color: var(--text-muted); margin-bottom: 10px; }
        .note-date { display: inline-block; background: var(--bg-input); padding: 4px 8px; border-radius: 4px; font-size: 0.85em; color: var(--text-muted); margin-bottom: 8px; transition: background 0.3s; }
        .editor-toolbar { display: flex; gap: 5px; background: var(--bg-input); padding: 5px; border: 1px solid var(--border-input); border-bottom: none; border-radius: 5px 5px 0 0; transition: background 0.3s, border-color 0.3s; }
        .editor-btn { background: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-main); border-radius: 4px; padding: 5px 10px; cursor: pointer; font-size: 14px; transition: background 0.3s, color 0.3s; }
        .editor-btn:hover { background: #e9ecef; }
        [data-theme="dark"] .editor-btn:hover { background: #333; }
        .editor-area { min-height: 150px; border: 1px solid var(--border-input); border-radius: 0 0 5px 5px; padding: 10px; outline: none; overflow-y: auto; background: var(--editor-bg); color: var(--text-main); transition: background 0.3s, color 0.3s, border-color 0.3s; }
        .editor-area:focus { border-color: #3498db; }
    </style>
<link rel="manifest" href="/manifest.json"><meta name="theme-color" content="#1e3c72">
</head>
<body data-theme="light">

<div class="container">
    <div class="header">
        <h1>Мой блокнот</h1>
        <div style="display: flex; align-items: center;">
            <button class="theme-btn" onclick="toggleTheme()" id="theme-toggle" title="Сменить тему">🌙</button>
            <span>Привет, <strong><?php echo e(Auth::user()->name); ?></strong>!</span>
            <form method="POST" action="/logout" class="logout-form">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-secondary" style="margin-left: 15px;">Выйти</button>
            </form>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="success"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="weather-card">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($weather): ?>
            <div class="weather-main">
                <img src="http://openweathermap.org/img/wn/<?php echo e($weather['icon']); ?>@4x.png" alt="icon">
                <div>
                    <div class="weather-city">📍 <?php echo e($weather['city']); ?></div>
                    <div class="weather-temp"><?php echo e($weather['temp']); ?>°C</div>
                    <div class="weather-desc"><?php echo e(ucfirst($weather['desc'])); ?></div>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($forecast): ?>
                <div class="forecast-container">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $forecast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="forecast-day">
                            <div class="forecast-date"><?php echo e(date('d.m', $day['date'])); ?></div>
                            <div style="font-size: 0.8em; opacity: 0.7;"><?php echo e(mb_strtolower(date('D', $day['date']))); ?></div>
                            <img src="http://openweathermap.org/img/wn/<?php echo e($day['icon']); ?>.png" alt="icon">
                            <div class="forecast-temp"><?php echo e(round($day['temp'])); ?>°</div>
                            <div class="forecast-desc"><?php echo e(mb_strtolower($day['desc'])); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php else: ?>
            <p style="opacity: 0.8;">Погода недоступна.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- ТУТ НАШ КРАСИВЫЙ КАЛЕНДАРЬ ВМЕСТО СТАРЫХ ПОЛЕЙ -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('date-calendar', []);

$__key = null;

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3980561819-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key);

echo $__html;

unset($__html);
unset($__key);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('search-notes', []);

$__key = null;

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3980561819-1', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key);

echo $__html;

unset($__html);
unset($__key);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <div class="card counter">
        Найдено заметок по фильтру: <strong><?php echo e($count); ?></strong>
    </div>

    <div class="card">
        <h2>Добавить заметку</h2>
        <div class="current-time">Сейчас на сервере: <?php echo e(date('d.m.Y H:i:s')); ?></div>
        <form action="<?php echo e(route('notes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="title" placeholder="Заголовок" required>
            <div class="editor-toolbar">
                <button type="button" class="editor-btn" data-command="bold"><b>Ж</b></button>
                <button type="button" class="editor-btn" data-command="italic"><i>К</i></button>
                <button type="button" class="editor-btn" data-command="underline"><u>Ч</u></button>
                <button type="button" class="editor-btn" data-command="insertUnorderedList">• Список</button>
            </div>
            <div contenteditable="true" class="editor-area" id="create_editor"></div>
            <input type="hidden" name="content" id="create_hidden">
            <select name="category_id">
                <option value="">-- Без категории --</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </select>
            <button type="submit" class="btn btn-success" style="width: 100%;">➕ Сохранить</button>
        </form>
    </div>

    <div class="card">
        <h2>Мои заметки</h2>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="note-item">
                <?php 
                    $badgeClass = 'badge-none'; 
                    if($note->category) {
                        if($note->category->name == 'Дом') $badgeClass = 'badge-home';
                        if($note->category->name == 'Работа') $badgeClass = 'badge-work';
                        if($note->category->name == 'Отдых') $badgeClass = 'badge-rest';
                    }
                ?>
                <span class="badge <?php echo e($badgeClass); ?>"><?php echo e($note->category ? $note->category->name : 'Без категории'); ?></span>
                <div class="note-date">📅 Создано: <?php echo e($note->created_at->format('d.m.Y в H:i')); ?></div>
                <strong><?php echo e($note->title); ?></strong>
                <div style="margin: 5px 0; color: var(--text-muted);"><?php echo $note->content; ?></div>
                <div class="note-actions">
                    <button class="btn btn-warning btn-sm" onclick="this.closest('.note-item').querySelector('.edit-form').style.display = 'flex'">✏️ Редактировать</button>
                    <form action="<?php echo e(route('notes.destroy', $note->id)); ?>" method="POST" onsubmit="return confirm('Точно удалить заметку?');" style="margin:0;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">🗑️ Удалить</button>
                    </form>
                </div>
                <form action="<?php echo e(route('notes.update', $note->id)); ?>" method="POST" class="edit-form" style="display: none;">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="text" name="title" value="<?php echo e($note->title); ?>" required placeholder="Новый заголовок">
                    <select name="category_id">
                        <option value="">-- Без категории --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e($note->category_id == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                    <div class="editor-toolbar">
                        <button type="button" class="editor-btn" data-command="bold"><b>Ж</b></button>
                        <button type="button" class="editor-btn" data-command="italic"><i>К</i></button>
                        <button type="button" class="editor-btn" data-command="underline"><u>Ч</u></button>
                        <button type="button" class="editor-btn" data-command="insertUnorderedList">• Список</button>
                    </div>
                    <div contenteditable="true" class="editor-area" id="edit_editor_<?php echo e($note->id); ?>"><?php echo e($note->content); ?></div>
                    <input type="hidden" name="content" id="edit_hidden_<?php echo e($note->id); ?>">
                    <button type="submit" class="btn btn-success">💾 Сохранить изменения</button>
                    <button type="button" class="btn btn-secondary" onclick="this.parentElement.style.display = 'none'">Отмена</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.editor-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            document.execCommand(this.dataset.command, false, null);
        });
    });
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            const editor = form.querySelector('.editor-area');
            const hidden = form.querySelector('input[type="hidden"][name="content"]');
            if (editor && hidden) { hidden.value = editor.innerHTML; }
        });
    });
});

function toggleTheme() {
    const body = document.body;
    const newTheme = body.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    body.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    document.getElementById('theme-toggle').innerText = newTheme === 'dark' ? '☀️' : '🌙';
}
window.onload = function() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.body.setAttribute('data-theme', savedTheme);
        document.getElementById('theme-toggle').innerText = savedTheme === 'dark' ? '☀️' : '🌙';
    }
};
</script>

<script>if ("serviceWorker" in navigator) { window.addEventListener("load", () => { navigator.serviceWorker.register("/sw.js"); }); }</script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/notes/index.blade.php ENDPATH**/ ?>