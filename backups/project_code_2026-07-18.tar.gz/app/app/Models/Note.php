<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;

class Note extends Model
{
    use Searchable;

    // ЖЕСТКО принудительно ставим ID=1 (или ту цифру, которую выдал Шаг 1)
    protected static function booted()
    {
        static::creating(function ($note) {
            $note->user_id = 1; // Если в Шаге 1 не было единицы, поменяйте здесь на ту цифру, которая была
        });
    }

    protected $fillable = [
        'user_id',
        'category_id',
        'title',
        'content',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function toSearchableArray()
    {
        return [
            'title' => $this->title,
            'content' => $this->content,
            'user_id' => $this->user_id,
            'category_id' => $this->category_id,
        ];
    }
}
