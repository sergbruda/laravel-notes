<?php

namespace App\Http\Controllers;

use App\Models\Note;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache; // <-- Подключили кэш

class NoteController extends Controller
{
    public function index(Request $request)
    {
        $notes = Note::with('category')->where('user_id', Auth::id());

        if ($request->filled('date_from')) {
            $notes->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $notes->whereDate('created_at', '<=', $request->date_to);
        }
        
        $notes = $notes->orderBy('created_at', 'desc')->get();
        $categories = Category::all();
        $count = $notes->count();

        $apiKey = env('WEATHER_API_KEY'); 
        
        if ($apiKey) {
            // МАГИЯ: Берем из кэша на 30 минут. Если пусто - выполняет код внутри и сама кладет в кэш
            $weather = Cache::remember('weather_current_ufa', now()->addMinutes(30), function () use ($apiKey) {
                $response = Http::get("https://api.openweathermap.org/data/2.5/weather", [
                    'q' => 'Ufa', 'appid' => $apiKey, 'units' => 'metric', 'lang' => 'ru'
                ]);
                if ($response->successful()) {
                    $w = $response->json();
                    return [
                        'city' => $w['name'], 
                        'temp' => $w['main']['temp'], 
                        'desc' => $w['weather'][0]['description'], 
                        'icon' => $w['weather'][0]['icon']
                    ];
                }
                return null;
            });

            $forecast = Cache::remember('weather_forecast_ufa', now()->addMinutes(30), function () use ($apiKey) {
                $forecastResponse = Http::get("https://api.openweathermap.org/data/2.5/forecast", [
                    'q' => 'Ufa', 'appid' => $apiKey, 'units' => 'metric', 'lang' => 'ru'
                ]);
                if ($forecastResponse->successful()) {
                    $forecastData = $forecastResponse->json();
                    $dailyForecast = [];
                    foreach ($forecastData['list'] as $item) {
                        $dateKey = date("Y-m-d", $item['dt']);
                        if (!isset($dailyForecast[$dateKey])) {
                            $dailyForecast[$dateKey] = [
                                'date' => $item['dt'],
                                'temp' => $item['main']['temp'],
                                'icon' => $item['weather'][0]['icon'],
                                'desc' => $item['weather'][0]['description']
                            ];
                        }
                    }
                    return array_slice($dailyForecast, 0, 5); 
                }
                return null;
            });
        } else {
            $weather = null;
            $forecast = null;
        }
        
        return view('notes.index', compact('notes', 'count', 'categories', 'weather', 'forecast', 'request'));
    }

    public function store(Request $request)
    {
        $request->validate(['title' => 'required|max:255']);
        Note::create(array_merge($request->only('title', 'content', 'category_id'), ['user_id' => Auth::id()]));
        
        // При добавлении заметки можно не чистить кэш погоды, но мы чистим кэш списка заметок (если он будет)
        return redirect()->back()->with('success', 'Заметка добавлена!');
    }

    public function update(Request $request, $id)
    {
        $note = Note::where('id', $id)->where('user_id', Auth::id())->firstOrFail();
        $request->validate(['title' => 'required|max:255']);
        $note->update($request->only('title', 'content', 'category_id'));
        return redirect()->back()->with('success', 'Заметка обновлена!');
    }

    public function destroy($id)
    {
        Note::where('id', $id)->where('user_id', Auth::id())->delete();
        return redirect()->back()->with('success', 'Заметка удалена!');
    }
}
